---
name: Al-Razy Homecare
colors:
  surface: '#f6fafb'
  surface-dim: '#d6dbdc'
  surface-bright: '#f6fafb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f4f5'
  surface-container: '#eaefef'
  surface-container-high: '#e5e9ea'
  surface-container-highest: '#dfe3e4'
  on-surface: '#171c1d'
  on-surface-variant: '#3e4949'
  inverse-surface: '#2c3132'
  inverse-on-surface: '#edf1f2'
  outline: '#6e7979'
  outline-variant: '#bdc9c9'
  surface-tint: '#00696c'
  primary: '#006769'
  on-primary: '#ffffff'
  primary-container: '#088285'
  on-primary-container: '#f2ffff'
  inverse-primary: '#77d5d8'
  secondary: '#a73736'
  on-secondary: '#ffffff'
  secondary-container: '#fd7772'
  on-secondary-container: '#710e14'
  tertiary: '#00685c'
  on-tertiary: '#ffffff'
  tertiary-container: '#008374'
  on-tertiary-container: '#f4fffb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#94f2f5'
  primary-fixed-dim: '#77d5d8'
  on-primary-fixed: '#002021'
  on-primary-fixed-variant: '#004f51'
  secondary-fixed: '#ffdad7'
  secondary-fixed-dim: '#ffb3ae'
  on-secondary-fixed: '#410004'
  on-secondary-fixed-variant: '#872021'
  tertiary-fixed: '#5cfae2'
  tertiary-fixed-dim: '#33ddc6'
  on-tertiary-fixed: '#00201b'
  on-tertiary-fixed-variant: '#005046'
  background: '#f6fafb'
  on-background: '#171c1d'
  surface-variant: '#dfe3e4'
typography:
  headline-xl:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 60px
  headline-xl-mobile:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 42px
  headline-lg:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 46px
  headline-lg-mobile:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 36px
  headline-sm:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 30px
  body-md:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-sm:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  label-lg:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  label-md:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-sm:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 18px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes a warm, deeply dignified, and medically reassuring digital environment tailored for Egyptian families seeking home healthcare for their elderly, chronic, or convalescing loved ones. Moving away from cold, sterile hospital aesthetics, the system embodies calm authority, domestic comfort, and grounded reliability. 

The aesthetic is Modern Humanist Healthcare: generous negative space, high contrast, warm ivory canvas layers, and structured clarity. The brand voice avoids hyperbolic medical promises and flashy high-tech gimmicks, emphasizing instead quiet competence, prompt accessibility, and respectful bedside manner. Visual elements favor touch clarity, clear typographic hierarchies in native RTL Arabic, and organic tactile warmth that eliminates anxiety for non-technical family decision-makers and senior patients alike.

## Colors

The palette is engineered around clinical competence tempered with organic warmth:
- **Primary (`#228D90` - Dark Turquoise):** Represents clinical rigor, modern patient hygiene, and stability. Used for primary CTAs, active state indicators, key service anchors, and primary contact highlights.
- **Secondary (`#962B2B` - Deep Crimson / Rich Red):** Introduces urgency, vital care emphasis, and strong focal contrast. Used for secondary CTAs, critical alerts, step indicator accents, and high-impact empathetic editorial callouts.
- **Tertiary (`#05CDB6` - Vibrant Teal / Aqua Accent):** Highlights specialized service badges, trust ratings, and secondary accents with a modern, fresh contrast.
- **Neutral (`#222728` - Deep Slate Charcoal):** Delivers WCAG AAA-compliant textual contrast against white and ivory backgrounds, avoiding the jarring harshness of pure black while retaining crisp readability.
- **Backgrounds (`surface-ivory`: `#FBFBFA`, `surface-tint`: `#F4F7F6`):** Natural layered off-whites that prevent screen glare for older eyes and give a comfortable editorial rhythm between sections.

## Typography

Typography prioritizes effortless legibility in native Arabic (`dir="rtl"`). The typographic scale relies on **IBM Plex Sans Arabic**, selected for its geometric balance, open counters, clear diacritic handling, and technical clarity at smaller sizes.

Key rules for Arabic typography application:
- Line-heights (`lineHeight`) are deliberately elevated by 15-25% compared to typical Latin scales to give Arabic diacritics and ascenders/descenders breathing room.
- Letter spacing is fixed at `0` for all Arabic text to preserve proper script ligature connections.
- Western and Arabic-Indic numerals are aligned systematically to prevent baseline misalignments across medical dosage instructions, phone numbers (`01124202420`), and service pricing tiers.

## Layout & Spacing

The layout is built upon an 8pt rhythmic grid within a 12-column responsive layout for desktop viewports, collapsing to a 4-column system on mobile devices.

- **Desktop (min-width: 1024px):** Max container width capped at `1240px` centered, utilizing `3rem` section margins and `1.5rem` gutters.
- **Tablet (768px – 1023px):** 8 columns, `2rem` side margins, `1rem` gutters.
- **Mobile (under 768px):** Single-column flow with `1.25rem` outer margins. 
- **Touch Areas:** Interactive touch targets must meet a minimum bounding box of 48×48px. Persistent bottom actions (quick emergency call, book service) must float above page content with an explicit safe area padding of `1rem` and must not obscure conversational copy or form inputs.

## Elevation & Depth

Visual hierarchy relies primarily on warm tonal layering, delicate structural borders, and subtle diffuse shadows. Heavy skeuomorphism and dark, murky shadows are avoided in favor of airy cleanliness.

- **Level 0 (Flat / Canvas):** Background surfaces (`#FFFFFF` and `#FBFBFA`) with zero elevation.
- **Level 1 (Cards & Modules):** Raised with a soft, warm-tinted shadow (`0 2px 8px -2px rgba(34, 39, 40, 0.05)`) paired with a subtle structural boundary border: `1px solid rgba(150, 43, 43, 0.15)`.
- **Level 2 (Hover & Focus States):** Elevated smoothly (`0 8px 20px -4px rgba(34, 141, 144, 0.12)`), providing tactile lift when users interact with clinical service cards or package options.
- **Level 3 (Overlays, Floating CTAs & Headers):** Sticky mobile navigation headers and persistent telephone CTA bars feature a diffused background blur (`backdrop-filter: blur(8px)`) over an 85% opacity surface (`rgba(251, 251, 250, 0.85)`), coupled with a bottom border `1px solid rgba(34, 141, 144, 0.1)`.

## Shapes

The shape system employs roundedness level **2 (Rounded)**:
- Baseline interactive elements (input fields, buttons, small selectors) feature an 8px (`0.5rem`) border radius.
- Cards, service panels, and modal containers use a 16px (`1rem`) radius (`rounded-lg`).
- High-prominence visual banners, promotional badges, and floating quick-dial telephone buttons use a 24px (`1.5rem`) radius (`rounded-xl`) or full pill styling to signal accessibility, physical safety, and warmth.

## Components

### Buttons
- **Primary Button ("احجز خدمتك الآن"):** Background in Primary Turquoise (`#228D90`), text in pure `#FFFFFF`, radius `0.5rem`, minimum height `48px`, padding `0.75rem 1.75rem`. Hover shifts to `#1A6F72`. Focus ring: `3px solid rgba(34, 141, 144, 0.35)`.
- **Secondary Button ("تفاصيل الخدمة"):** Outline variant with `1.5px solid #962B2B`, text `#962B2B`, background transparent. Hover transitions to `#F4F7F6` with text `#752121`.
- **Urgent / Direct-Dial Button (`tel:01124202420`):** Pill-shaped container, filled with `#228D90`, paired with a white phone icon positioned to the right of the Arabic label.

### Cards & Service Containers
- Built on `#FFFFFF` with a `1px solid rgba(150, 43, 43, 0.18)` border and `rounded-lg` corners.
- Padding: `1.5rem`.
- Structure: Icon/Badge top-right, followed by H3 title (`headline-sm`), 2-line service summary (`body-md`), and inline link action at the bottom-left.

### Input Fields & Forms
- Text, Tel, and Select fields feature a `48px` height, `#FFFFFF` background, and `1px solid #D5DCDB` border.
- Active / Focused: Border transitions to `#228D90` with an outer halo of `rgba(34, 141, 144, 0.15)`.
- Error state: Border `#C83E3E` with an inline error hint positioned below the field, right-aligned in Arabic.
- File upload dropzones (CV submission): Dashed border `2px dashed #962B2B` on `#F4F7F6` background.

### Checkboxes & Radios
- Size: 20×20px with `rounded` corners (4px radius for checkboxes; 50% for radios).
- Checked: Solid `#228D90` fill with white check glyph. Focus ring ensures clear visibility for users navigating via assistive technology or keyboards.

### Service Chips & Badges
- Height: `28px`, padding: `0.25rem 0.75rem`, `rounded-xl`.
- Subtle status fills: Background `rgba(5, 205, 182, 0.1)`, text `#049e8c`, font `label-sm`.

### Accordion (FAQ Modules)
- Full-width dividers with `1px solid #E8ECEB`.
- Expandable chevron indicator positioned on the left margin, rotating 180 degrees smoothly on trigger, while question text anchors firmly to the right.